/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.portalacademico.modelo;

/**
 *
 * @author Damian
 */
public class EstudianteRegular extends MiembroFacultad{
    
    private double promedioAcumulado;

    public EstudianteRegular() {
    }

    public EstudianteRegular(double promedioAcumulado) {
        this.promedioAcumulado = promedioAcumulado;
    }

    public EstudianteRegular(double promedioAcumulado, String rutId, String nombreCompleto, String emailInstitucional) {
        super(rutId, nombreCompleto, emailInstitucional);
        this.promedioAcumulado = promedioAcumulado;
    }

    

    public double getPromedioAcumulado() {
        return promedioAcumulado;
    }

    public void setPromedioAcumulado(double promedioAcumulado) {
        this.promedioAcumulado = promedioAcumulado;
    }

    @Override
    public String toString() {
        return "EstudianteRegular{" + "promedioAcumulado=" + promedioAcumulado + '}';
    }

    public String inscribirAsignatura(){
        return "Lenguaje";
    }
    
}
