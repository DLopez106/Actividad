/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.observatorio.modelo;

/**
 *
 * @author Damian
 */
public class TelescopioOptico extends TelescopioAstronomico {
    
    private String tipoFiltroColor;

    public TelescopioOptico() {
    }

    public TelescopioOptico(String tipoFiltroColor) {
        this.tipoFiltroColor = tipoFiltroColor;
    }

    public TelescopioOptico(String tipoFiltroColor, String idTelescopio, double diametroEspejosMetros, boolean enOrientacion) {
        super(idTelescopio, diametroEspejosMetros, enOrientacion);
        this.tipoFiltroColor = tipoFiltroColor;
        }


    public String getTipoFiltroColor() {
        return tipoFiltroColor;
    }

    public void setTipoFiltroColor(String tipoFiltroColor) {
        this.tipoFiltroColor = tipoFiltroColor;
    }

    @Override
    public void capturarImagenData() {
        super.capturarImagenData(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
    @Override
    public String toString() {
        return "TelescopioOptico{" + "tipoFiltroColor=" + tipoFiltroColor + '}';
    }
    
    public String cambiarFiltro(){
        
        return null;    
    }
       
    
    
}
