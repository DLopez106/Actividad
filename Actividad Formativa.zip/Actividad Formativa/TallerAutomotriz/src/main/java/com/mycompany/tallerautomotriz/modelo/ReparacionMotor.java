/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tallerautomotriz.modelo;

/**
 *
 * @author Damian
 */
public class ReparacionMotor extends ServicioMecanico{
    
    private double horasTrabajoMecanico;
    private EscanerDiagnostico escaner0DB;

    public ReparacionMotor() {
    }

    public ReparacionMotor(double horasTrabajoMecanico, EscanerDiagnostico escaner0DB) {
        this.horasTrabajoMecanico = horasTrabajoMecanico;
        this.escaner0DB = escaner0DB;
    }

    public ReparacionMotor(double horasTrabajoMecanico, EscanerDiagnostico escaner0DB, String idOrden, String patenteVehiculo, double manoObraBase) {
        super(idOrden, patenteVehiculo, manoObraBase);
        this.horasTrabajoMecanico = horasTrabajoMecanico;
        this.escaner0DB = escaner0DB;
    }

    

    public double getHorasTrabajoMecanico() {
        return horasTrabajoMecanico;
    }

    public void setHorasTrabajoMecanico(double horasTrabajoMecanico) {
        this.horasTrabajoMecanico = horasTrabajoMecanico;
    }

    public EscanerDiagnostico getEscaner0DB() {
        return escaner0DB;
    }

    public void setEscaner0DB(EscanerDiagnostico escaner0DB) {
        this.escaner0DB = escaner0DB;
    }

    @Override
    public void calcularCostoTotal() {
        super.calcularCostoTotal(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
    @Override
    public String toString() {
        return "ReparacionMotor{" + "horasTrabajoMecanico=" + horasTrabajoMecanico + ", escaner0DB=" + escaner0DB + '}';
    }
    
    public void escanearComputadorVehiculo(){
        
    }
    
}
