/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.observatorio.modelo;

/**
 *
 * @author Damian
 */
public class EspectrometroLaser {
    
    private String rangoLongitudOnda;
    private double  temperaturaKelvin;

    public EspectrometroLaser() {
    }

    public EspectrometroLaser(String rangoLongitudOnda, double temperaturaKelvin) {
        this.rangoLongitudOnda = rangoLongitudOnda;
        this.temperaturaKelvin = temperaturaKelvin;
    }

    public String getRangoLongitudOnda() {
        return rangoLongitudOnda;
    }

    public void setRangoLongitudOnda(String rangoLongitudOnda) {
        this.rangoLongitudOnda = rangoLongitudOnda;
    }

    public double getTemperaturaKelvin() {
        return temperaturaKelvin;
    }

    public void setTemperaturaKelvin(double temperaturaKelvin) {
        this.temperaturaKelvin = temperaturaKelvin;
    }

    @Override
    public String toString() {
        return "EspectrometroLaser{" + "rangoLongitudOnda=" + rangoLongitudOnda + ", temperaturaKelvin=" + temperaturaKelvin + '}';
    }
    
    
    
    public void analizarComposicionQuimica(){
        
    }
    
}
