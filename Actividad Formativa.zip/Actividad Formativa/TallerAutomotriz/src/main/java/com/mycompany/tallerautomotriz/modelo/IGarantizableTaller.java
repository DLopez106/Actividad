/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.tallerautomotriz.modelo;

/**
 *
 * @author Damian
 */
public interface IGarantizableTaller {
    int emitirCertificadoGarantia();
    void validarEstadoPiezasOriginales();
}
