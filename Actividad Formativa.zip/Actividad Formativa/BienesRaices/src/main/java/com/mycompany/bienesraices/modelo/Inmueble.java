/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bienesraices.modelo;

/**
 *
 * @author Damian
 */
public abstract class Inmueble {
    
    private String rolMatriz;
    private String direccion;
    private double metrosCuadras;

    public Inmueble() {
    }

    public Inmueble(String rolMatriz, String direccion, double metrosCuadras) {
        this.rolMatriz = rolMatriz;
        this.direccion = direccion;
        this.metrosCuadras = metrosCuadras;
    }

    public String getRolMatriz() {
        return rolMatriz;
    }

    public void setRolMatriz(String rolMatriz) {
        this.rolMatriz = rolMatriz;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public double getMetrosCuadras() {
        return metrosCuadras;
    }

    public void setMetrosCuadras(double metrosCuadras) {
        this.metrosCuadras = metrosCuadras;
    }

    @Override
    public String toString() {
        return "Inmueble{" + "rolMatriz=" + rolMatriz + ", direccion=" + direccion + ", metrosCuadras=" + metrosCuadras + '}';
    }
    
    public void calcularContribuciones(){
        
    }
    public void publicarEnCatalogo(){
        
    }
    
}
