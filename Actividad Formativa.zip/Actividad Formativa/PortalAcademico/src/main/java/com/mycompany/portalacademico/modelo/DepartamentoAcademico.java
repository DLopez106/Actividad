/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.portalacademico.modelo;

/**
 *
 * @author Damian
 */
public class DepartamentoAcademico {
    
    private String nombreDepto;
    private double presupuestoInvestigacion;

    public DepartamentoAcademico() {
    }

    public DepartamentoAcademico(String nombreDepto, double presupuestoInvestigacion) {
        this.nombreDepto = nombreDepto;
        this.presupuestoInvestigacion = presupuestoInvestigacion;
    }

    public String getNombreDepto() {
        return nombreDepto;
    }

    public void setNombreDepto(String nombreDepto) {
        this.nombreDepto = nombreDepto;
    }

    public double getPresupuestoInvestigacion() {
        return presupuestoInvestigacion;
    }

    public void setPresupuestoInvestigacion(double presupuestoInvestigacion) {
        this.presupuestoInvestigacion = presupuestoInvestigacion;
    }

    @Override
    public String toString() {
        return "DepartamentoAcademico{" + "nombreDepto=" + nombreDepto + ", presupuestoInvestigacion=" + presupuestoInvestigacion + '}';
    }
    
    public void aprobarProyecto(){
        
    }
    
}
