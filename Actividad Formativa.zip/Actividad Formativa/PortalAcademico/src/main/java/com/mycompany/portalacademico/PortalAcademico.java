/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.portalacademico;

/**
 *
 * @author Damian
 */
public class PortalAcademico {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
