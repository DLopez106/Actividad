/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taquillacine.modelo;

/**
 *
 * @author Damian
 */
public abstract class TicketCine {
    
    private String idTicket;
    private String nombrePelicula;
    private double precioBase;

    public TicketCine() {
    }

    public TicketCine(String idTicket, String nombrePelicula, double precioBase) {
        this.idTicket = idTicket;
        this.nombrePelicula = nombrePelicula;
        this.precioBase = precioBase;
    }

    public String getIdTicket() {
        return idTicket;
    }

    public void setIdTicket(String idTicket) {
        this.idTicket = idTicket;
    }

    public String getNombrePelicula() {
        return nombrePelicula;
    }

    public void setNombrePelicula(String nombrePelicula) {
        this.nombrePelicula = nombrePelicula;
    }

    public double getPrecioBase() {
        return precioBase;
    }

    public void setPrecioBase(double precioBase) {
        this.precioBase = precioBase;
    }

    @Override
    public String toString() {
        return "TicketCine{" + "idTicket=" + idTicket + ", nombrePelicula=" + nombrePelicula + ", precioBase=" + precioBase + '}';
    }
    
    public void calcularPrecioTotal(){
        
    }
    public void imprimirTicket(){
        
    }
}
