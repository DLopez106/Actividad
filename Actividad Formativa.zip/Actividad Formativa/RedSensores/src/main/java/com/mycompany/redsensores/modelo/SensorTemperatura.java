/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.redsensores.modelo;

/**
 *
 * @author Damian
 */
public abstract class SensorTemperatura extends SensorIndustrial implements INotificableAlarma{
    
    private double gradosCelsius;

    public SensorTemperatura() {
    }

    public SensorTemperatura(double gradosCelsius) {
        this.gradosCelsius = gradosCelsius;
    }

    public SensorTemperatura(double gradosCelsius, String idSensor, String ubicacionArea, boolean activo) {
        super(idSensor, ubicacionArea, activo);
        this.gradosCelsius = gradosCelsius;
    }

    

    public double getGradosCelsius() {
        return gradosCelsius;
    }

    public void setGradosCelsius(double gradosCelsius) {
        this.gradosCelsius = gradosCelsius;
    }

    @Override
    public abstract void enviarNotificacionMQTT();

    @Override
    public abstract void dispararSirenaEmergencia();

    @Override
    public void tomarLectura() {
        super.tomarLectura(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
    @Override
    public String toString() {
        return "SensorTemperatura{" + "gradosCelsius=" + gradosCelsius + '}';
    }
    
    
    
}
