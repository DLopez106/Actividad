/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taquillacine.modelo;

/**
 *
 * @author Damian
 */
public class EntradaVIP extends TicketCine{
    private boolean menuGourmet;
    private ServicioBar atencionBar;

    public EntradaVIP() {
    }

    public EntradaVIP(boolean menuGourmet, ServicioBar atencionBar) {
        this.menuGourmet = menuGourmet;
        this.atencionBar = atencionBar;
    }

    public EntradaVIP(boolean menuGourmet, ServicioBar atencionBar, String idTicket, String nombrePelicula, double precioBase) {
        super(idTicket, nombrePelicula, precioBase);
        this.menuGourmet = menuGourmet;
        this.atencionBar = atencionBar;
    }

    

    public boolean isMenuGourmet() {
        return menuGourmet;
    }

    public void setMenuGourmet(boolean menuGourmet) {
        this.menuGourmet = menuGourmet;
    }

    public ServicioBar getAtencionBar() {
        return atencionBar;
    }

    public void setAtencionBar(ServicioBar atencionBar) {
        this.atencionBar = atencionBar;
    }

    @Override
    public void calcularPrecioTotal() {
        super.calcularPrecioTotal(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
    @Override
    public String toString() {
        return "EntradaVIP{" + "menuGourmet=" + menuGourmet + ", atencionBar=" + atencionBar + '}';
    }
    
    public void pedirPopcornTrufa(){
        
    }
}
