/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.operacioneslogisticas;

/**
 *
 * @author Damian
 */
public class OperacionesLogisticas {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
