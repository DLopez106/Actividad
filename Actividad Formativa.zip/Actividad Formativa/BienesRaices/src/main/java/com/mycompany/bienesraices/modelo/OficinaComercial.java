/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bienesraices.modelo;

/**
 *
 * @author Damian
 */
public class OficinaComercial extends Inmueble {
    
    private int banosPrivados;
    private TasadorOficial expertoTasador;

    public OficinaComercial() {
    }

    public OficinaComercial(int banosPrivados, TasadorOficial expertoTasador) {
        this.banosPrivados = banosPrivados;
        this.expertoTasador = expertoTasador;
    }

    public OficinaComercial(int banosPrivados, TasadorOficial expertoTasador, String rolMatriz, String direccion, double metrosCuadras) {
        super(rolMatriz, direccion, metrosCuadras);
        this.banosPrivados = banosPrivados;
        this.expertoTasador = expertoTasador;
    }

   

    public int getBanosPrivados() {
        return banosPrivados;
    }

    public void setBanosPrivados(int banosPrivados) {
        this.banosPrivados = banosPrivados;
    }

    public TasadorOficial getExpertoTasador() {
        return expertoTasador;
    }

    public void setExpertoTasador(TasadorOficial expertoTasador) {
        this.expertoTasador = expertoTasador;
    }

    @Override
    public void calcularContribuciones() {
        super.calcularContribuciones(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
    @Override
    public String toString() {
        return "OficinaComercial{" + "banosPrivados=" + banosPrivados + ", expertoTasador=" + expertoTasador + '}';
    }
    
    public void solicitarInformeTasacion(){
        
    }
    
}
