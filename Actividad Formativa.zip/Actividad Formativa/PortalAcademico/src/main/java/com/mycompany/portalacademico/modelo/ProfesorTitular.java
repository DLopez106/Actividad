/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.portalacademico.modelo;

/**
 *
 * @author Damian
 */
public class ProfesorTitular extends MiembroFacultad{
    
    private int horasDocencia;
    private DepartamentoAcademico deptoPertenece;

    public ProfesorTitular() {
    }

    public ProfesorTitular(int horasDocencia, DepartamentoAcademico deptoPertenece) {
        this.horasDocencia = horasDocencia;
        this.deptoPertenece = deptoPertenece;
    }

    public ProfesorTitular(int horasDocencia, DepartamentoAcademico deptoPertenece, String rutId, String nombreCompleto, String emailInstitucional) {
        super(rutId, nombreCompleto, emailInstitucional);
        this.horasDocencia = horasDocencia;
        this.deptoPertenece = deptoPertenece;
    }

    

    public int getHorasDocencia() {
        return horasDocencia;
    }

    public void setHorasDocencia(int horasDocencia) {
        this.horasDocencia = horasDocencia;
    }

    public DepartamentoAcademico getDeptoPertenece() {
        return deptoPertenece;
    }

    public void setDeptoPertenece(DepartamentoAcademico deptoPertenece) {
        this.deptoPertenece = deptoPertenece;
    }

    @Override
    public String toString() {
        return "ProfesorTitular{" + "horasDocencia=" + horasDocencia + ", deptoPertenece=" + deptoPertenece + '}';
    }
    
    public void postularFondoInvestigacion(){
        
    }
    
    
    
}
