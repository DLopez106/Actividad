/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.e.commerce.modelo;

/**
 *
 * @author Damian
 */
public class EncriptadorRSA {
    private int longitudLlave;
    private String tokenSeguridad;
    
    public String encriptadorDatos;
    
}
