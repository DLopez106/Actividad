/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bienesraices.modelo;

/**
 *
 * @author Damian
 */
public abstract class TerrenoAgricola extends Inmueble implements IFirmableDigital {
    
    private String tipoSuelo;

    public TerrenoAgricola() {
    }

    public TerrenoAgricola(String tipoSuelo) {
        this.tipoSuelo = tipoSuelo;
    }

    public TerrenoAgricola(String tipoSuelo, String rolMatriz, String direccion, double metrosCuadras) {
        super(rolMatriz, direccion, metrosCuadras);
        this.tipoSuelo = tipoSuelo;
    }

   

    public String getTipoSuelo() {
        return tipoSuelo;
    }

    public void setTipoSuelo(String tipoSuelo) {
        this.tipoSuelo = tipoSuelo;
    }

    @Override
    public abstract void verificarFirmaToken();

    @Override
    public abstract void firmarPromesaNotarial();

    @Override
    public void calcularContribuciones() {
        super.calcularContribuciones(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
    @Override
    public String toString() {
        return "TerrenoAgricola{" + "tipoSuelo=" + tipoSuelo + '}';
    }
    
    
           
    
}
