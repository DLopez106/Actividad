/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bienesraices.modelo;

/**
 *
 * @author Damian
 */
public class TasadorOficial {
    
    private String nombreTasador;
    private String numRegistroNacional;

    public TasadorOficial() {
    }

    public TasadorOficial(String nombreTasador, String numRegistroNacional) {
        this.nombreTasador = nombreTasador;
        this.numRegistroNacional = numRegistroNacional;
    }

    public String getNombreTasador() {
        return nombreTasador;
    }

    public void setNombreTasador(String nombreTasador) {
        this.nombreTasador = nombreTasador;
    }

    public String getNumRegistroNacional() {
        return numRegistroNacional;
    }

    public void setNumRegistroNacional(String numRegistroNacional) {
        this.numRegistroNacional = numRegistroNacional;
    }

    @Override
    public String toString() {
        return "TasadorOficial{" + "nombreTasador=" + nombreTasador + ", numRegistroNacional=" + numRegistroNacional + '}';
    }
    
    public void calcularValorComercialUF(){
        
    }
    
}
