/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.flotavehiculos;

/**
 *
 * @author Damian
 */
public class FlotaVehiculos {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
