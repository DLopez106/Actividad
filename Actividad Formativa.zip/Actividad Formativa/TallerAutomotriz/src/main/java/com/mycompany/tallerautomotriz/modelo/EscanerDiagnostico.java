/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tallerautomotriz.modelo;

/**
 *
 * @author Damian
 */
public class EscanerDiagnostico{
    private String marcaEscaner;
    private String versionSoftware;

    public EscanerDiagnostico() {
    }

    public EscanerDiagnostico(String marcaEscaner, String versionSoftware) {
        this.marcaEscaner = marcaEscaner;
        this.versionSoftware = versionSoftware;
    }

    public String getMarcaEscaner() {
        return marcaEscaner;
    }

    public void setMarcaEscaner(String marcaEscaner) {
        this.marcaEscaner = marcaEscaner;
    }

    public String getVersionSoftware() {
        return versionSoftware;
    }

    public void setVersionSoftware(String versionSoftware) {
        this.versionSoftware = versionSoftware;
    }

    @Override
    public String toString() {
        return "EscanerDiagnostico{" + "marcaEscaner=" + marcaEscaner + ", versionSoftware=" + versionSoftware + '}';
    }
    
    public void leerCodigosFalla0BD2(){
        
    }
    
}
