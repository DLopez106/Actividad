/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.e.commerce;

/**
 *
 * @author Damian
 */
public class ECommerce {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
