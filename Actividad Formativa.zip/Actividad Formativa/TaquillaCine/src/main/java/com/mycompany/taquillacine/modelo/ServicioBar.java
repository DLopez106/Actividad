/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taquillacine.modelo;

/**
 *
 * @author Damian
 */
public class ServicioBar {
    private String numButaca;
    private boolean incluyeBebidaRefill;

    public ServicioBar() {
    }

    public ServicioBar(String numButaca, boolean incluyeBebidaRefill) {
        this.numButaca = numButaca;
        this.incluyeBebidaRefill = incluyeBebidaRefill;
    }

    public String getNumButaca() {
        return numButaca;
    }

    public void setNumButaca(String numButaca) {
        this.numButaca = numButaca;
    }

    public boolean isIncluyeBebidaRefill() {
        return incluyeBebidaRefill;
    }

    public void setIncluyeBebidaRefill(boolean incluyeBebidaRefill) {
        this.incluyeBebidaRefill = incluyeBebidaRefill;
    }

    @Override
    public String toString() {
        return "ServicioBar{" + "numButaca=" + numButaca + ", incluyeBebidaRefill=" + incluyeBebidaRefill + '}';
    }
    
    public void enviarComboButaca(){
        
    }
    
}
