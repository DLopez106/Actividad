/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bienesraices;

/**
 *
 * @author Damian
 */
public class BienesRaices {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
