/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.librohechizos;

/**
 *
 * @author Damian
 */
public class MotorPersonajes09 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
