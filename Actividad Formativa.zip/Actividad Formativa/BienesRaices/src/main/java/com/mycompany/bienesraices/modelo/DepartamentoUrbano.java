/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bienesraices.modelo;

/**
 *
 * @author Damian
 */
public class DepartamentoUrbano extends Inmueble {
    
    private int pisoNumero;

    public DepartamentoUrbano() {
    }

    public DepartamentoUrbano(int pisoNumero) {
        this.pisoNumero = pisoNumero;
    }

    public DepartamentoUrbano(int pisoNumero, String rolMatriz, String direccion, double metrosCuadras) {
        super(rolMatriz, direccion, metrosCuadras);
        this.pisoNumero = pisoNumero;
    }

    

    public int getPisoNumero() {
        return pisoNumero;
    }

    public void setPisoNumero(int pisoNumero) {
        this.pisoNumero = pisoNumero;
    }

    @Override
    public void calcularContribuciones() {
        super.calcularContribuciones(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
    @Override
    public String toString() {
        return "DepartamentoUrbano{" + "pisoNumero=" + pisoNumero + '}';
    }

    public void solicitarEstacionamientoVisita(){
        
    }
    
}
