/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tallerautomotriz.modelo;

/**
 *
 * @author Damian
 */
public class MantencionPreventiva extends ServicioMecanico{
    
    private boolean cambioFiltrosIncluido;

    public MantencionPreventiva() {
    }

    public MantencionPreventiva(boolean cambioFiltrosIncluido) {
        this.cambioFiltrosIncluido = cambioFiltrosIncluido;
    }

    public MantencionPreventiva(boolean cambioFiltrosIncluido, String idOrden, String patenteVehiculo, double manoObraBase) {
        super(idOrden, patenteVehiculo, manoObraBase);
        this.cambioFiltrosIncluido = cambioFiltrosIncluido;
    }

   

    public boolean isCambioFiltrosIncluido() {
        return cambioFiltrosIncluido;
    }

    public void setCambioFiltrosIncluido(boolean cambioFiltrosIncluido) {
        this.cambioFiltrosIncluido = cambioFiltrosIncluido;
    }

    @Override
    public void calcularCostoTotal() {
        super.calcularCostoTotal(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
    @Override
    public String toString() {
        return "MantencionPreventiva{" + "cambioFiltrosIncluido=" + cambioFiltrosIncluido + '}';
    }
    
    public void rellenarFluidoFrenos(){
        
    }
    
}
