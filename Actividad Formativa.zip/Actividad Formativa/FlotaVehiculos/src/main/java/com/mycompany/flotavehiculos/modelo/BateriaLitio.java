/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.flotavehiculos.modelo;

/**
 *
 * @author Damian
 */
public class BateriaLitio{
 
    private double capacidadKWh;
    private int porcentajeCarga;
 
    public BateriaLitio() {}
 
    public int getPorcentajeCarga(){
       return 0; 
    }
       
}
        
    
  