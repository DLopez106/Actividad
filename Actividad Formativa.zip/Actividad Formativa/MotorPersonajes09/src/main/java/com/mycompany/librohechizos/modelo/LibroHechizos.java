/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.librohechizos.modelo;

/**
 *
 * @author Damian
 */
public class LibroHechizos {
    private int totalGrimorios;
    private String elementoDominante;
    
    public void buscarRunaPoderosa(){
        
    }
}
