/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taquillacine.modelo;

/**
 *
 * @author Damian
 */
public class EntradaEstandar extends TicketCine{
    private char filaLetra;

    public EntradaEstandar() {
    }

    public EntradaEstandar(char filaLetra) {
        this.filaLetra = filaLetra;
    }

    public EntradaEstandar(char filaLetra, String idTicket, String nombrePelicula, double precioBase) {
        super(idTicket, nombrePelicula, precioBase);
        this.filaLetra = filaLetra;
    }

    

    public char getFilaLetra() {
        return filaLetra;
    }

    public void setFilaLetra(char filaLetra) {
        this.filaLetra = filaLetra;
    }

    @Override
    public void calcularPrecioTotal() {
        super.calcularPrecioTotal(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
    @Override
    public String toString() {
        return "EntradaEstandar{" + "filaLetra=" + filaLetra + '}';
    }
    
    public void canjearPuntosCine(){
        
    }
    
}
