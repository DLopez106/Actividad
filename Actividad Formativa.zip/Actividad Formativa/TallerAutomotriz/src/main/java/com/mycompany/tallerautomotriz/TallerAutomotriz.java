/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tallerautomotriz;

/**
 *
 * @author Damian
 */
public class TallerAutomotriz {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
