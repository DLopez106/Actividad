/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taquillacine.modelo;

/**
 *
 * @author Damian
 */
public abstract class PaseFestival extends TicketCine implements IEscaneableNFC{
    private int diasValidez;

    public PaseFestival() {
    }

    public PaseFestival(int diasValidez) {
        this.diasValidez = diasValidez;
    }

    public PaseFestival(int diasValidez, String idTicket, String nombrePelicula, double precioBase) {
        super(idTicket, nombrePelicula, precioBase);
        this.diasValidez = diasValidez;
    }

    

    public int getDiasValidez() {
        return diasValidez;
    }

    public void setDiasValidez(int diasValidez) {
        this.diasValidez = diasValidez;
    }

    @Override
    public void calcularPrecioTotal() {
        super.calcularPrecioTotal(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
    @Override
    public String toString() {
        return "PaseFestival{" + "diasValidez=" + diasValidez + '}';
    }
    
 
              
}
