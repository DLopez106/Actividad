/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.observatorio.modelo;

/**
 *
 * @author Damian
 */
public abstract class TelescopioAstronomico {
    
    private String idTelescopio;
    private double diametroEspejosMetros;
    private boolean enOrientacion;

    public TelescopioAstronomico() {
    }

    public TelescopioAstronomico(String idTelescopio, double diametroEspejosMetros, boolean enOrientacion) {
        this.idTelescopio = idTelescopio;
        this.diametroEspejosMetros = diametroEspejosMetros;
        this.enOrientacion = enOrientacion;
    }

    public String getIdTelescopio() {
        return idTelescopio;
    }

    public void setIdTelescopio(String idTelescopio) {
        this.idTelescopio = idTelescopio;
    }

    public double getDiametroEspejosMetros() {
        return diametroEspejosMetros;
    }

    public void setDiametroEspejosMetros(double diametroEspejosMetros) {
        this.diametroEspejosMetros = diametroEspejosMetros;
    }

    public boolean isEnOrientacion() {
        return enOrientacion;
    }

    public void setEnOrientacion(boolean enOrientacion) {
        this.enOrientacion = enOrientacion;
    }

    @Override
    public String toString() {
        return "TelescopioAstronomico{" + "idTelescopio=" + idTelescopio + ", diametroEspejosMetros=" + diametroEspejosMetros + ", enOrientacion=" + enOrientacion + '}';
    }
    
    public double apuntarACoordenadas(){
        return 1;          
    }
    public void capturarImagenData(){
    }
    
}
