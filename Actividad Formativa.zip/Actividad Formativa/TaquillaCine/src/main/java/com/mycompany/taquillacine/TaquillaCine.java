/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.taquillacine;

/**
 *
 * @author Damian
 */
public class TaquillaCine {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
