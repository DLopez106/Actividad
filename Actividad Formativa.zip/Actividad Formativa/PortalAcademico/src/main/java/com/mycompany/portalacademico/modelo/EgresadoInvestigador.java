/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.portalacademico.modelo;

/**
 *
 * @author Damian
 */
public abstract class EgresadoInvestigador extends MiembroFacultad implements IExportableCV{
    
    private int anioGraduacion;

    public EgresadoInvestigador() {
    }

    public EgresadoInvestigador(int anioGraduacion) {
        this.anioGraduacion = anioGraduacion;
    }

    public EgresadoInvestigador(int anioGraduacion, String rutId, String nombreCompleto, String emailInstitucional) {
        super(rutId, nombreCompleto, emailInstitucional);
        this.anioGraduacion = anioGraduacion;
    }


    public int getAnioGraduacion() {
        return anioGraduacion;
    }

    public void setAnioGraduacion(int anioGraduacion) {
        this.anioGraduacion = anioGraduacion;
    }

    @Override
    public String toString() {
        return "EgresadoInvestigador{" + "anioGraduacion=" + anioGraduacion + '}';
    }

    @Override
    public abstract void exportarPDFResumido();

    @Override
    public abstract void generarFormatoORCID();
    
    
    
}
