/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.redsensores.modelo;

/**
 *
 * @author Damian
 */
public class SensorPresion extends SensorIndustrial{
    
    private double PresionPSI;
    private CalibradorDigital dispositivoCalibrador;

    public SensorPresion() {
    }

    public SensorPresion(double PresionPSI, CalibradorDigital dispositivoCalibrador) {
        this.PresionPSI = PresionPSI;
        this.dispositivoCalibrador = dispositivoCalibrador;
    }

    public SensorPresion(double PresionPSI, CalibradorDigital dispositivoCalibrador, String idSensor, String ubicacionArea, boolean activo) {
        super(idSensor, ubicacionArea, activo);
        this.PresionPSI = PresionPSI;
        this.dispositivoCalibrador = dispositivoCalibrador;
    }

    

    public double getPresionPSI() {
        return PresionPSI;
    }

    public void setPresionPSI(double PresionPSI) {
        this.PresionPSI = PresionPSI;
    }

    public CalibradorDigital getDispositivoCalibrador() {
        return dispositivoCalibrador;
    }

    public void setDispositivoCalibrador(CalibradorDigital dispositivoCalibrador) {
        this.dispositivoCalibrador = dispositivoCalibrador;
    }

    @Override
    public void tomarLectura() {
        super.tomarLectura(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
    @Override
    public String toString() {
        return "SensorPresion{" + "PresionPSI=" + PresionPSI + ", dispositivoCalibrador=" + dispositivoCalibrador + '}';
    }
    
    public void medirDeltaPresion(){
        
    }
    
}
