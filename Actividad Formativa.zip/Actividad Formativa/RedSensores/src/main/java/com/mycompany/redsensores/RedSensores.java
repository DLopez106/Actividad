/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.redsensores;

/**
 *
 * @author Damian
 */
public class RedSensores {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
