/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tallerautomotriz.modelo;

/**
 *
 * @author Damian
 */
public abstract class ServicioMecanico{
    
    private String idOrden;
    private String patenteVehiculo;
    private double manoObraBase;

    public ServicioMecanico() {
    }

    public ServicioMecanico(String idOrden, String patenteVehiculo, double manoObraBase) {
        this.idOrden = idOrden;
        this.patenteVehiculo = patenteVehiculo;
        this.manoObraBase = manoObraBase;
    }

    public String getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(String idOrden) {
        this.idOrden = idOrden;
    }

    public String getPatenteVehiculo() {
        return patenteVehiculo;
    }

    public void setPatenteVehiculo(String patenteVehiculo) {
        this.patenteVehiculo = patenteVehiculo;
    }

    public double getManoObraBase() {
        return manoObraBase;
    }

    public void setManoObraBase(double manoObraBase) {
        this.manoObraBase = manoObraBase;
    }

    @Override
    public String toString() {
        return "ServicioMecanico{" + "idOrden=" + idOrden + ", patenteVehiculo=" + patenteVehiculo + ", manoObraBase=" + manoObraBase + '}';
    }
    
    public void calcularCostoTotal(){
        
    }
    public void finalizarServicio(){
        
    }
}
