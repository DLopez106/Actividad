/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.observatorio.modelo;

/**
 *
 * @author Damian
 */
public abstract class RadioTelescopio extends TelescopioAstronomico implements IProcesablefits{
    
    private double frecuenciaGHz;

    public RadioTelescopio() {
    }

    public RadioTelescopio(double frecuenciaGHz) {
        this.frecuenciaGHz = frecuenciaGHz;
    }

    public RadioTelescopio(double frecuenciaGHz, String idTelescopio, double diametroEspejosMetros, boolean enOrientacion) {
        super(idTelescopio, diametroEspejosMetros, enOrientacion);
        this.frecuenciaGHz = frecuenciaGHz;
    }

    

    public double getFrecuenciaGHz() {
        return frecuenciaGHz;
    }

    public void setFrecuenciaGHz(double frecuenciaGHz) {
        this.frecuenciaGHz = frecuenciaGHz;
    }

    @Override
    public String toString() {
        return "RadioTelescopio{" + "frecuenciaGHz=" + frecuenciaGHz + '}';
    }
    
    
    
}
