/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tallerautomotriz.modelo;

/**
 *
 * @author Damian
 */
public abstract class AfinacionElectrica extends ServicioMecanico implements IGarantizableTaller {
    
    private int repuestosCombinados;

    public AfinacionElectrica() {
    }

    public AfinacionElectrica(int repuestosCombinados) {
        this.repuestosCombinados = repuestosCombinados;
    }

    public AfinacionElectrica(int repuestosCombinados, String idOrden, String patenteVehiculo, double manoObraBase) {
        super(idOrden, patenteVehiculo, manoObraBase);
        this.repuestosCombinados = repuestosCombinados;
    }


    public int getRepuestosCombinados() {
        return repuestosCombinados;
    }

    public void setRepuestosCombinados(int repuestosCombinados) {
        this.repuestosCombinados = repuestosCombinados;
    }

    @Override
    public void calcularCostoTotal() {
        super.calcularCostoTotal(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("AfinacionElectrica{");
        sb.append("repuestosCombinados=").append(repuestosCombinados);
        sb.append('}');
        return sb.toString();
    }
    
    
}
