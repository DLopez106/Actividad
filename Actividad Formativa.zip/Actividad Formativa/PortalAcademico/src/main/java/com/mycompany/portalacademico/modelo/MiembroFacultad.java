/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.portalacademico.modelo;

/**
 *
 * @author Damian
 */
public class MiembroFacultad {
    
    private String rutId;
    private String nombreCompleto;
    private String emailInstitucional;

    public MiembroFacultad() {
    }

    public MiembroFacultad(String rutId, String nombreCompleto, String emailInstitucional) {
        this.rutId = rutId;
        this.nombreCompleto = nombreCompleto;
        this.emailInstitucional = emailInstitucional;
    }

    public String getRutId() {
        return rutId;
    }

    public void setRutId(String rutId) {
        this.rutId = rutId;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getEmailInstitucional() {
        return emailInstitucional;
    }

    public void setEmailInstitucional(String emailInstitucional) {
        this.emailInstitucional = emailInstitucional;
    }

    @Override
    public String toString() {
        return "MiembroFacultad{" + "rutId=" + rutId + ", nombreCompleto=" + nombreCompleto + ", emailInstitucional=" + emailInstitucional + '}';
    }
    
    public void obtenerPerfilCompleto(){
        
    }
    public void ingresarPortal(){
        
    }
    
    
}
