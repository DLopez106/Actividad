/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.observatorio.modelo;

/**
 *
 * @author Damian
 */
public class TelescopioEspacial extends TelescopioAstronomico {
    private double orbitaAltitudKm;
    private EspectrometroLaser espectrometro;

    public TelescopioEspacial() {
    }

        public TelescopioEspacial(double orbitaAltitudKm, EspectrometroLaser espectrometro) {
            this.orbitaAltitudKm = orbitaAltitudKm;
            this.espectrometro = espectrometro;
        }

        public TelescopioEspacial(double orbitaAltitudKm, EspectrometroLaser espectrometro, String idTelescopio, double diametroEspejosMetros, boolean enOrientacion) {
            super(idTelescopio, diametroEspejosMetros, enOrientacion);
            this.orbitaAltitudKm = orbitaAltitudKm;
            this.espectrometro = espectrometro;
        }


    public double getOrbitaAltitudKm() {
        return orbitaAltitudKm;
    }

    public void setOrbitaAltitudKm(double orbitaAltitudKm) {
        this.orbitaAltitudKm = orbitaAltitudKm;
    }

    public EspectrometroLaser getEspectrometro() {
        return espectrometro;
    }

    public void setEspectrometro(EspectrometroLaser espectrometro) {
        this.espectrometro = espectrometro;
    }

    @Override
    public void capturarImagenData() {
        super.capturarImagenData(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
    @Override
    public String toString() {
        return "TelescopioEspacial{" + "orbitaAltitudKm=" + orbitaAltitudKm + ", espectrometro=" + espectrometro + '}';
    }
    
    public void realizarEspectrocopiaEstelar(){
        
    }
    
    
}
