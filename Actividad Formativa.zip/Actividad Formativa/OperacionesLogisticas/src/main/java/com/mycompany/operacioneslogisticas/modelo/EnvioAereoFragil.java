/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.operacioneslogisticas.modelo;

/**
 *
 * @author Damian
 */
public abstract class EnvioAereoFragil extends PaqueteEnvio implements IAsegurableRiesgo{
    
    private double valorDeclarado;

    public EnvioAereoFragil() {
    }

    public EnvioAereoFragil(double valorDeclarado) {
        this.valorDeclarado = valorDeclarado;
    }

    public EnvioAereoFragil(double valorDeclarado, String numeroGuia, double pesoKg, String destino) {
        super(numeroGuia, pesoKg, destino);
        this.valorDeclarado = valorDeclarado;
    }

    

    public double getValorDeclarado() {
        return valorDeclarado;
    }

    public void setValorDeclarado(double valorDeclarado) {
        this.valorDeclarado = valorDeclarado;
    }

    @Override
    public abstract void emitirCertificadoProteccion();

    @Override
    public abstract void cotizarPolizSeguro();

    @Override
    public void calcularCostoEnvio() {
        super.calcularCostoEnvio(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
    @Override
    public String toString() {
        return "EnvioAereoFragil{" + "valorDeclarado=" + valorDeclarado + '}';
    }
    
    
    
}
